<template>
  <div style="height:30px" id="scrolling-techniques">
    <h1>
      GROUPS page.
    </h1>
  </div>
</template>

<script>
  export default {
    name: 'Group',

    data: () => ({
      
    }),
  }
</script>
